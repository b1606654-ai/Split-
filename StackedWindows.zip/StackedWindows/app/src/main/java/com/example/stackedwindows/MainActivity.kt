package com.example.stackedwindows

import android.app.Activity
import android.app.ActivityOptions
import android.app.PendingIntent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private data class AppItem(val label: String, val pkg: String) {
        override fun toString() = label
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }

        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f }
        fun spinner() = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, apps)
        }

        val top = spinner()
        val bottom = spinner()
        val button = Button(this).apply { text = "قسّم الشاشة" }

        root.addView(label("التطبيق العلوي"))
        root.addView(top)
        root.addView(label("التطبيق السفلي"))
        root.addView(bottom)
        root.addView(button)
        setContentView(root)

        button.setOnClickListener {
            val a = top.selectedItem as? AppItem ?: return@setOnClickListener
            val b = bottom.selectedItem as? AppItem ?: return@setOnClickListener
            val screen = windowManager.maximumWindowMetrics.bounds
            val mid = screen.top + screen.height() / 2
            try {
                launch(a.pkg, Rect(screen.left, screen.top, screen.right, mid), 1)
                Handler(Looper.getMainLooper()).postDelayed({
                    try {
                        launch(b.pkg, Rect(screen.left, mid, screen.right, screen.bottom), 2)
                    } catch (e: Exception) {
                        Toast.makeText(this, "تعذّر فتح الثاني: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }, 900)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذّر الفتح: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun launch(pkg: String, bounds: Rect, code: Int) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val options = ActivityOptions.makeBasic().setLaunchBounds(bounds)
        if (Build.VERSION.SDK_INT >= 34) {
            options.setPendingIntentBackgroundActivityStartMode(
                ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            options.setPendingIntentCreatorBackgroundActivityStartMode(
                ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
        }
        val pi = PendingIntent.getActivity(
            this, code, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        pi.send(this, 0, null, null, null, null, options.toBundle())
    }
}
